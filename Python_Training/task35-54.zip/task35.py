# Предложите пользователю
# ввести имя. Выведите
# имя три раза.

name = input('Enter a name: ')
for name in range(1, 4):
    #result = name 
    print(name)
    